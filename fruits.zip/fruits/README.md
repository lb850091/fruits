# fruits

Hi, due to times limitation i cound realy implement as well as i wanted
if i had time i would use redux to update the state of stop/start but didn't have time
also i would add proper animation and using caching
Didn't manage to do the search but if i had time i would use state
{
isPause,
filter
}

## Available Scripts

In the project directory, you can run:

### `npm run dev`
