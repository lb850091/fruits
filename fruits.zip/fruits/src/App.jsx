import { useState } from "react";
import { Fruits } from "./components/Fruits";
import "./App.css";

function App() {
  const [paused, setPaused] = useState(false);
  return (
    <>
      <div className="fruits-container">
        <header>
          <button type="button" onClick={() => setPaused(true)}>
            stop
          </button>
          <button type="button" onClick={() => setPaused(false)}>
            play
          </button>
        </header>

        <Fruits isPaused={paused}></Fruits>
      </div>
    </>
  );
}

export default App;
