import { useState, useEffect, useRef } from "react";

export const Fruits = (isPaused) => {
  const [fruits, setFruits] = useState([]);
  const ws = useRef(null);

  useEffect(() => {
    ws.current = new WebSocket("wss://socket-example-20v3.onrender.com/");
    const wsCurrent = ws.current;
    return () => {
      if (wsCurrent.readyState === 1) {
        wsCurrent.close();
      }
    };
  }, []);

  useEffect(() => {
    if (!ws.current) return;
    ws.current.onmessage = (e) => {
      if (isPaused === true) return;

      const message = JSON.parse(e.data);
      setFruits((f) => [message, ...f]);
    };
  }, [isPaused]);

  const fuitsList = fruits.map((item, index) => {
    return (
      <div className="fruit" key={index}>
        <div
          style={{ backgroundColor: item.color }}
          className="fruit-circle"
        ></div>
        <div className="fruit-title">
          <span>{item.name}</span>
          <span>{item.weight}</span>
        </div>
      </div>
    );
  });

  return (
    <>
      <div>{fuitsList}</div>
    </>
  );
};
